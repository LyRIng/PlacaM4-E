//=============================================================================
//
//                       Adapted from: PSoC Design Challenge 2002
//                           (PROJECT NUMBER 248) Revised
//
//=============================================================================
//  FILENAME:   comm.c
//   VERSION:   1.05 by R.Oliva
//      DATE:   13-6-06 Changed all to UART_2 (to make it work)
//              Counter_2: Vc3 = 24e6 /2 Period = 155, Compare = 77 in ctr8_2().
//
//  DESCRIPTION:
//  Functions for RS232 communication
//=============================================================================
#include "m8c.h"
//#include "psocdynamic.h"
//#include "lcr.h"
#include "comm.h"
#include "stdlib.h"
#include "string.h"
//#include "counter8_1.h" // 27.1.04
#include "UART_2.h"       // 27.1.04
//#include "thermistor5.h" // 4.2.04


//switch on debugging: define DEBUG
#define DEBUGx
// #define RX_LOCAL_FUNCTION (bypass old RX.., for new API-2006)
#define RX_TMPSTRLEN 20

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_Start
// DESCRIPTION:        Starts Comm config
// ARGUMENTS:          
// Adapted:			   RBO. 3.2.04
// RETURNS:            nothing
// SIDE EFFECTS:       Uses Comm blocks
// THEORY of OPERATION:none.
//-----------------------------------------------------------------------------
void Comm_Start (void)
{
   // Was in main, now in CommStart.
   // Counter8_1's 24MHz/12 (N=12 for the ADC!) Clock (24V1 = 2MHz) is divided by 
   // nPeriod= 13 to obtain 153.8kHz(ideally 153.6) which is the 8x19200 input
   // clock which will be used for UART. Compare value is 7 or 8
   // Problems with n=13,19200 sends rubbish (with 7 or 8)! 
   // Try 8 x 9600 baud, this means nPeriod - 26, compare is 13.
   //nPeriod = 26;
   //Counter8_1_WritePeriod(nPeriod);
   //Counter8_1_DisableInt();
   //Counter8_1_Start();
   // Comm Counter ready..
   // Clock is available thru pin 24, P0_0..
   // Added two first commands.. 10.2.2006
   UART_2_CmdReset();                      // Initialize receiver/cmd  
                                           // buffer  
   UART_2_IntCntl(UART_2_RXBUF_ENABLE);     // Enable RX interrupts   
   // This was here..
   UART_2_Start(UART_PARITY_NONE);         // Was in main().. 3.2.04 moved to comm.c
   //Comm_TxCStr ("Comm_init OK");         // 10.6.06 elim..
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_Stop
// DESCRIPTION:        Stops Comm config
// ARGUMENTS:          
// Adapted:			   RBO. 3.2.04 Not used..
// RETURNS:            nothing
// SIDE EFFECTS:       Uses Comm blocks
// THEORY of OPERATION:none.
//-----------------------------------------------------------------------------
void Comm_Stop (void)
{
    //UnloadConfig_Comm ();
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_TxByte
// DESCRIPTION:        Sends TmpStr string to RS232
// ARGUMENTS:          Global var: TmpStr
// RETURNS:            nothing
// SIDE EFFECTS:       
//                     Uses TmpStr
//                     Uses Comm blocks
// THEORY of OPERATION:none.
//-----------------------------------------------------------------------------
void Comm_TxInt (int i)
{
    itoa (TmpStr, i, 10);
    Comm_TxStr (TmpStr);
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_TxStr
// DESCRIPTION:        Sends TmpStr string to RS232
// Adapted:			   RBO. 3.2.04 /elim. Case..
// ARGUMENTS:          Global var: TmpStr
// RETURNS:            nothing
// SIDE EFFECTS:       Uses TmpByte
//                     Uses Comm blocks
// THEORY of OPERATION:Safety counter added, strings less than 255..
//-----------------------------------------------------------------------------
void Comm_TxStr (char *TxStr)
{
BYTE Safety_Counter = 0;
    while (*TxStr)            // If null, stop
    {
        Comm_TxByte (*TxStr); // Echo Byte back to COM   
        TxStr++;              // Increment ptr..
        if(++Safety_Counter == 255) 
              {return;}       // Prevent infinite looping..
    }
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_TxCStr
// DESCRIPTION:        Sends constant string to RS232
// ARGUMENTS:          const char *
// Adapted:			   RBO. 3.2.04
// RETURNS:            nothing
// SIDE EFFECTS:       
//                     Uses Comm blocks
// THEORY of OPERATION:Added Safety counter < 255...
//-----------------------------------------------------------------------------
void Comm_TxCStr (const char *TxStr)
{
BYTE Safety_Counter = 0;
    while (*TxStr)
    {
        Comm_TxByte (*TxStr);
        TxStr++;        
        if(++Safety_Counter == 255) 
              {return;}       // Prevent infinite looping..

    }
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_TxByte
// DESCRIPTION:        Sends TmpStr string to RS232
// Adapted:			   RBO. 3.2.04 
// ARGUMENTS:          Global var: TmpStr
// RETURNS:            nothing
// SIDE EFFECTS:       Uses TmpByte
//                     Uses Comm blocks
// THEORY of OPERATION:Changed notation..
//-----------------------------------------------------------------------------
void Comm_TxByte (char ch)
{
    //wait until TX ready
    while( !(bUART_2_ReadTxStatus() & UART_TX_BUFFER_EMPTY) ); 
    // while (!(Comm_UART_TX_CONTROL_REG & UART_TX_BUFFER_EMPTY));
    // Comm_UART_TX_BUFFER_REG = ch;
    // while (!(Comm_UART_TX_CONTROL_REG & UART_TX_COMPLETE));
    UART_2_TX_BUFFER_REG = ch;
    while( !(bUART_2_ReadTxStatus() & UART_TX_COMPLETE));
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_TxCRLF
// DESCRIPTION:        Sends CRLF to RS232
// ARGUMENTS:          
// RETURNS:            nothing
// SIDE EFFECTS:       
//                     Uses Comm blocks
// THEORY of OPERATION:none.
//-----------------------------------------------------------------------------
void Comm_TxCRLF (void)
{
    Comm_TxByte (CR);
    Comm_TxByte (LF);
}

//-----------------------------------------------------------------------------
// FUNCTION NAME:      Comm_RxTmpStr
// DESCRIPTION:        Reads string from RS232, writes to TmpStr
//                     Return if kbd interrupt, eliminated
// Adapted:			   RBO. 3.2.04 
// ARGUMENTS:          
// RETURNS:            global TmpStr
// SIDE EFFECTS:       
//                     Uses Comm blocks
// THEORY of OPERATION:none.
// #ifdef'd for new API - 02-2006
//-----------------------------------------------------------------------------
#ifdef RX_LOCAL_FUNCTION
void Comm_RxTmpStr (void)
{
    BYTE StrIdx = 0;
    BYTE bRxStatus;
    int TimeOut = COMMTIMEOUT;  
    char ch;
    
    while (1)
    {    
        // loop until RX received / Eliminated 'select' key pressed
        // in TH4 it was..
        // '1' indicates Send Count + temp
        // '2' sends 24LC256 contents..
        
        // Take care of timeout..
        if(--TimeOut == 0)
           {    
                TmpStr[StrIdx] = 0;
                // Debug..Comm_TxByte ('.');
                return;
           }
        // Something came?
        if ( (bRxStatus = bUART_2_ReadRxStatus() & UART_RX_COMPLETE) != 0)
          {
           ch = NAK_RESPONSE; //Preset Response..
           // Something came, see if OK
           if ( !(bRxStatus & UART_RX_NO_ERROR)) {
               ch = bUART_2_ReadRxData(); // Get byte received
               Comm_TxByte (ch);          // Echo..
               } // inner if..      
           // If it's an enter 
           if (ch == CR) 
               {
               Comm_TxByte (LF); // Transmit LF
               TmpStr[StrIdx] = 0; // And exit, first terminating string..
               return;
           }
           TmpStr[StrIdx++] = ch; // If not, increment string pointer and check length..
           if (StrIdx == RX_TMPSTRLEN) // If exceeds max, terminate string an exit..
           {
               TmpStr[StrIdx] = 0;
               return;
           }
        } // end if something came..
      }   // End infinite while..  
 }        // End function..
#endif