

// Main.h - File 
// Includes Constants that depend on compilation
// R.Oliva 2010
// For M4_exp Boards, in Petrobras 2  - v18.8.2010
// Updated for M4_Ev3 in PWRC/ii 02-01-2012

// Story: 
// R.Oliva - 17.12.2005
//          -- Build 14 - Accomodate Constants for UNSIGNED A/D
// Freno 19 15.2.2006 
// Correct TH values, for real test on 

// For Freno20 - Correct various problems..

// Freno 22_c29 - Cloned for C29 chip family.. 10.6.06
// 13.6.06 v24 With new Save to EVT..
// 17.6.06 v25 Setup corrected, See notes..
// 11.8.06 v27 Correct MAX number of EVTs to 1770.., version N� too..
// 16.8.2006 v28 For LosPozos, change to 25.0V or 4096
// 12.06 Freno 29 w/problems.- Adjust Levels w/user interface.
// 14.02.07 Freno 30- Manual Mode does not work.
// 25.10.2007- Freno31-Petrobras / 48V
// ---- #define VTH_LO_BEXT 4096
// 28.10.07 v32_c29 - Modified IAERO equation for 0 to 50, y Ref Vdd/2 +/- Vdd/2
// 2.11.2007 v33 OK pero modificar Ecuacion para ACS755 en 0A -- 0.6V
//           Adem�s, contempla P2.4 On-off Diesel..

// Freno485_v1 7-10-2009 Basado en Fren33b, incorpora RS485
// Freno485_v6 5.5.2010 Cambiar MSG
// Freno485_v7 19.5.2010 Add State Machine #defines..
// M4E_ v2010 para Petrobras/2
// M4E_v3 - 2011/12 para PWRC/ii -INTI

// Program Labels -
// Updated for M4_Ev3 in PWRC/ii 02-01-2012
const char PGM_MSG1[]= " M4Exp3_TRIADC v2.1 4-03-2012";

