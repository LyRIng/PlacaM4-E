//----------------------------------------------------------------------------
// C main line M4E_3a_AVR
// R.Oliva - M4EXP BOARD AS I2C Slave "ezI2C" for PWRC/CL2bm1
// REV 14-02-2012 with Triadc, based on 3a (based on test2_m4e_avr from 23-12-10)
// Rev2 04-3-2012
//----------------------------------------------------------------------------

// Commented as (**) -> 2011 add-ons in M4E/3
// Initial:
// Modified 10.5.09 To support 400kHz in EzI2C module configuration(was in 100khz)
// Also flashes a LED on P00 as in EM/12, to show life..
// OK! Starts communicating with AVR..
// Rev.3_29.4.10 Change to reflect use on M4 as Freno:
//     1. Nueva Struct con 3 primeros R/W (LEDppal, RelayK0, RlayKAux) BYTE 1 o 0
//         resto ser�a analogicos (uint 10x) Vf_input (0-1000); Vbex(0-700); Vbi(0-160); Vtemp(2230-3250) 
//         y digitales R only: BYTE 1 o 0 
//                  AbSwitch
//                  CerrSwitch
//                  USR_FrenoAbierto-Cerrado;
//                  USR_Freno-ManAuto;
//      2. Relays work OK 
//
// RevM4Exp: Maps real future M4 board I/O into the program, as follows (13.7.10)
//     PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//
//     PORT1: 3 are outputs, 1 as input
//          P1.7  P1.6  P1.5  P1.4   P1.3  P1.2  P1.1  P1.0
//          HSC   OUT2  HSDA   OUT1   IN4   OUT0  --*ISSP*--
//
//
// (**)CORRECTED Port0:***********************************************************
//     23-11-2011
//     PORT0: 4 Act as analog inputs, usual 2 as Serialport and LED/relay.
//          P0.7  P0.6  P0.5  P0.4   P0.3  P0.2  P0.1  P0.0
//          V_A1  RxD   V_A2  TxD    VA_3  K_aux VTMP  LED_Out
//         (=VRPM)     (=V_IAER)    (=VBAT)
// (**)*********** end correction ************************************************
//    a) Defines for OUT0,1,2 and LED_out, K_aux ready.
//    TO DO: 
//    b) Set them as strong outputs in DEVICE
//    c) Define their BYTE association in R/W area, document it. 
//    d) Set loop ADProcess() or similar for 4 AD Channels, Device define as AnlgInps            
//
// (**)CORRECTED POWER_OK control:************************************************         
//     23-11-2011
//     POWER_OK control. Not used in this version PWRC/ii and SanJulian
// (**)*********** end correction ************************************************

//  9-8-2010 (testm4exp2_avr) Input reading - Mostly on Port2, copy to: 
//  BYTE bIN0_P27;    // Input IN0 (0 or 1)
//  BYTE bIN1_P25;    // Input IN1 (0 or 1)
//  BYTE bIN2_P23;    // Input IN2 (0 or 1)
//  BYTE bIN2to0;      // Input value IN2-IN0 (000 to 111)- Dos.Mode
//  BYTE bIN3_P21;    // Input IN3 (0 or 1)
//  BYTE bIN4_P13;    // Input IN4 (0 or 1)
//  BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
//  BYTE bIN14_P20;   // Input IN14 (0 or 1)
//  BYTE bIN15_P22;   // Input IN15 (0 or 1)
//  BYTE bIN16_P24;   // Input IN16 (0 or 1)
//  BYTE bIN17_P26;   // Input IN17 (0 or 1)
//
//  from m8c.h
//-----------------------------------------------
//  Global Interrupt Enable/Disable
//-----------------------------------------------
// #define  M8C_EnableGInt          asm("or  F, 01h")
// #define  M8C_DisableGInt         asm("and F, FEh")
// 

//
// ******************** INPUT SCANNING CODE. *************************************************************************
//    I) Read Input IN0 requires testing P2.7: if high -> IN.0 =1, else IN.0=0
//    This requires a) Copying PORT2 to Temp.

//                     Temp_Holder=PRT2DR; // Make a single "photo" copy of port status..

//                     Temp = Temp_Holder;  // Don't overwrite copy.. 
//                  b) Temp = Temp & 0x80;   // Mask 0b1000 0000: Read P2_7, Temp will be 0x80 if P2.7 high, 0 if low
//                  c) if (Temp)  M4E3_I2C_Regs.bIN0_P27  = 1;
//                        else  M4E3_I2C_Regs.bIN0_P27  = 0;
//    Remember PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//    II) Read Input IN1 requires testing P2.5: if high -> IN.1 =1, else IN.1=0
//    This requires  (Use same Temp_Holder as a))
//                  d) Temp=Temp_Holder;
//                  e) Temp = Temp & 0x20;   // Mask 0b0010 0000: Read P2_5, Temp will be 0x20 if P2.5 high, 0 if low
//                  f) if (Temp)  M4E3_I2C_Regs.bIN1_P25  = 1;
//                        else  M4E3_I2C_Regs.bIN1_P25  = 0;
//    III) Read Input IN2 requires testing P2.3: if high -> IN.2 =1, else IN.2=0
//    This requires  (Use same Temp_Holder as a))
//                  d) Temp=Temp_Holder;
//                  e) Temp = Temp & 0x08;   // Mask 0b0000 1000: Read P2_3, Temp will be 0x08 if P2.3 high, 0 if low
//                  f) if (Temp)  M4E3_I2C_Regs.bIN2_P23  = 1;
//                        else  M4E3_I2C_Regs.bIN2_P23  = 0;
//    IV) Read Inputs IN2-0 as a Dosif_Mode status byte 000 to 111:
//    This can be done with 3 bits just calculated, in theory IN.2*pow(2,2)+IN.1*pow(2,1)+IN.0*pow(2,0)
//                  g) M4E3_I2C_Regs.bIN2to0  = (M4E3_I2C_Regs.bIN2_P23)*4+(M4E3_I2C_Regs.bIN1_P25)*2+M4E3_I2C_Regs.bIN0_P27;
//    To debug, these values should be sent out thru the serial port..
//    V) Now read
//                 BYTE bIN3_P21;    // Input IN3 (0 or 1)
//                 BYTE bIN4_P13;    // Input IN4 (0 or 1)
//                 BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
//    V-a) Read Input IN3 requires testing P2.1: if high -> IN.3 =1, else IN.3=0
//    This requires  (Use same Temp_Holder as a))
//                  h) Temp=Temp_Holder;
//                  i) Temp = Temp & 0x02;   // Mask 0b0000 0010: Read P2_1, Temp will be 0x02 if P2.1 high, 0 if low
//                  j) if (Temp)  M4E3_I2C_Regs.bIN3_P21  = 1;
//                        else  M4E3_I2C_Regs.bIN3_P21  = 0;
//    V-b) Read Input IN4 requires testing P1.3: if high -> IN.4 =1, else IN.4=0

//                     Temp=PRT1DR;    // Make a single copy on Temp, not used again..

//                  l) Temp = Temp & 0x08;   // Mask 0b0000 1000: Read P1_3, Temp will be 0x08 if P1.3 high, 0 if low
//                  m) if (Temp)  M4E3_I2C_Regs.bIN4_P13 = 1;
//                        else  M4E3_I2C_Regs.bIN4_P13  = 0;
//    VI) Read Inputs IN4-3 as a Freno_Mode status byte 00 to 11:
//    This can be done with 2 bits just calculated, in theory IN.4*pow(2,1)+IN.3*pow(2,0)
//                  n) M4E3_I2C_Regs.bIN4to3  = (M4E3_I2C_Regs.bIN4_P13)*2+M4E3_I2C_Regs.bIN3_P21;
//    VII) Rest of inputs, all on Port2
//      BYTE bIN14_P20;   // Input IN14 (0 or 1)
//      BYTE bIN15_P22;   // Input IN15 (0 or 1)
//      BYTE bIN16_P24;   // Input IN16 (0 or 1)
//      BYTE bIN17_P26;   // Input IN17 (0 or 1)
//      Remember PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//
//    VIIa) Read Input IN14 requires testing P2.0: if high -> IN.14 =1, else IN.14=0
//                  o) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  p) Temp = Temp & 0x01;   // Mask 0b0000 0001: Read P2_0, Temp will be 0x01 if P2.0 high, 0 if low
//                  q) if (Temp)  M4E3_I2C_Regs.bIN14_P20  = 1;
//                        else  M4E3_I2C_Regs.bIN14_P20  = 0;
//    VIIb) Read Input IN15 requires testing P2.2: if high -> IN.15 =1, else IN.15=0
//                  r) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  s) Temp = Temp & 0x04;   // Mask 0b0000 0100: Read P2_2, Temp will be 0x04 if P2.2 high, 0 if low
//                  t) if (Temp)  M4E3_I2C_Regs.bIN15_P22  = 1;
//                        else  M4E3_I2C_Regs.bIN15_P22  = 0;
//    VIIc) Read Input IN16 requires testing P2.4: if high -> IN.16 =1, else IN.16=0
//                  u) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  v) Temp = Temp & 0x10;   // Mask 0b0001 0000: Read P2_4, Temp will be 0x10 if P2.4 high, 0 if low
//                  w) if (Temp)  M4E3_I2C_Regs.bIN16_P24  = 1;
//                        else  M4E3_I2C_Regs.bIN16_P24  = 0;
//    VIId) Read Input IN17 requires testing P2.6: if high -> IN.17 =1, else IN.17=0
//                  u) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  v) Temp = Temp & 0x40;   // Mask 0b0100 0000: Read P2_6, Temp will be 0x40 if P2.6 high, 0 if low
//                  w) if (Temp)  M4E3_I2C_Regs.bIN17_P26  = 1;
//                        else  M4E3_I2C_Regs.bIN17_P26  = 0;
//       Re-enable INTs.. 18.8.2010
// ******************** OK - Trhu with all inputs.. *******************************************************************

// (**)CORRECTED Analog Inputs****************************************************         
//unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
//unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
//unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
//unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
//unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>
// PWR_OK control commented out in M4E_v3 -2012
// (**)*********** end correction ************************************************

// New Struct:
//struct M4Exp3_I2C_Regs { // M4Exp3 I2C interface structure, first 6 are R/-W
//BYTE bVector;     // To signal IRQ type, ID on Interrupt to master
//BYTE bOut_0;      // Controls PWR_OK signal - active hi
//BYTE bOut_1;      // Controls Buzzer - active hi
//BYTE bOut_2;      // Auxiliary output - Not assigned
//BYTE bOut_LED;    // LED on board - Active hi
//BYTE bOut_K_Aux;  // Auxiliary Relay - Closes on hi
//BYTE bIN0_P27;    // Input IN0 (0 or 1)
//BYTE bIN1_P25;    // Input IN1 (0 or 1)
//BYTE bIN2_P23;    // Input IN2 (0 or 1)
//BYTE bIN2-0;      // Input value IN2-IN0 (000 to 111)- (Former ->Dos.Mode PB/2)
//BYTE bIN3_P21;    // Input IN3 (0 or 1)
//BYTE bIN4_P13;    // Input IN4 (0 or 1)
//BYTE bIN4-3;      // Input value IN4-IN3 (00 to 11) - (Former->Freno Mode PB/2)
//BYTE bIN14_P20;   // Input IN14 (0 or 1)
//BYTE bIN15_P22;   // Input IN15 (0 or 1)
//BYTE bIN16_P24;   // Input IN16 (0 or 1)
//BYTE bIN17_P26;   // Input IN17 (0 or 1)
//unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
//unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
//unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
//unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
//unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>
//char ID_cStr[6];  // Read only string for ID purpose
//} M4E3_I2C_Regs;

//
//  Seudocode (Copied to main.c - 23-11-2011):
/*  SEUDOCODE VM4_E3
	Initialize_struct I2C
	Initialize I2C RAM/ROM area
	Initialize_AD_inputs
	Start I2C
	Start ADConversions
	Set Watchdog
	Enable interrupts
	loop endless {
                     Read Last M4E3_I2C_Regs Struct to Temp var
			   Write outputs if struct was updated 
			       (if Power_OK is under M4 control, P1.2 is masked)
	               Read P2 port 
			   Mask and update IN2-IN0 from P2 in Temp var
			   Mask and update IN3-IN4 (P2/P1) in Temp var
			   Mask and update IN17-IN14 in Temp var
			   Read 4 A/D channels to Temp var
			   disable interrupts
			   {
			    write Temp var to M4E3_I2C_Regs Struct
			   }
			   enable interrupts   
			   // CPU should beep if Vbat_Ave close to VbminLo
			   // Eliminate Vbat_control on PWR_OK (not necessary)
     } // end of loop      
*/

  
//**********************************************************
// Code 
//
// This code will setup the EzI2Cs slave to expose a data
// structure to the I2C bus.
//
// The instance name of the EzI2Cs User Module is assumed
// to be EzI2Cs.
//
//
//************************************************************
#include <m8c.h>      // Part specific constants and macros
#include "PSoCAPI.h"  // PSoC API definitions for all User Modules
#include <string.h>
#include "math.h"
#include "stdlib.h"      // 1.9.03 to add ftoa()
#include "comm.h"        // 3.2.04 Comm routines (ELIMINATE Thermistor 5)
#include "main.h"        // 8.9.05 - Constants that vary commonly.


// Port0_0 is LED-err 10.5.09
// Remember to set P00 as out-Strong in Device Config!!
#define Port0_0(b) (PRT0DR = (b==0) ? (PRT0DR&0xFE):(PRT0DR|0x01))
#define DELAY_LED_SHORT  1000
//#define DELAY_LED_MAX_ON 60000
//#define DELAY_LED_MAX_OFF 60000 
// Try shorter delays to update AVG values.. 20000
#define DELAY_LED_MAX_ON 20000
#define DELAY_LED_MAX_OFF 20000


// Port0_2 is K_AUX Relay 12.7.2010
// Remember to set P02 as out-Strong in Device Config!!
#define Port0_2(b) (PRT0DR = (b==0) ? (PRT0DR&0xFB):(PRT0DR|0x04))

// Port1_2 is OUT_0=PWR_OK (Active Hi) 12.7.2010
// Remember to set P1_2 as out-Strong in Device Config!!
#define Port1_2(b) (PRT1DR = (b==0) ? (PRT1DR&0xFB):(PRT1DR|0x04))

// Port1_4 is OUT_1=BUZZ (Active Hi) 12.7.2010
// Remember to set P1_4 as out-Strong in Device Config!!
#define Port1_4(b) (PRT1DR = (b==0) ? (PRT1DR&0xEF):(PRT1DR|0x10))

// Port1_6 is OUT_2 (Active Hi) 12.7.2010
// Remember to set P1_6 as out-Strong in Device Config!!
#define Port1_6(b) (PRT1DR = (b==0) ? (PRT1DR&0xBF):(PRT1DR|0x40))

// For Temperature: unsigned int iV_Tempx10;   // Integer 0-65536 x 10 Kelvin temperature P0.7
// Constants: From adjusted (not measured) TC1047A curve and GN= 1+R1/R2 = 2.818, 
// Should be: 0�C = 273�K -> 1.48V on P0.1
//            40�C = 313�K -> 2.536V on P0.1- Constants (see calc on Green PB2 cuaderno, P68)
//            Considering a 13-bit converter, 5.0V = 8191counts, so Vx * 8191 / 5.0 = Cx counts..
//            Vp01a = 1.48V --> C1_0�c = 1.48/5.0*8191 = 2424.5 cuentas
//            Vp01b = 2.536V -->C1_40�C = 2.536*81891/5.0 = 4154.5 cuentas
//            float TinDegK = K_TEMP * (float)C1_xx + OFF_TEMP;
float TinDegK = 0.0;
//            iV_Tempx10 = (unsigned int)(10.0*TinDegK);   
#define K_TEMP 0.023121
#define OFF_TEMP 216.954
// b) For Vbat (PWR_OK control)
//            VP0.3 = 3.07 V for Vbat = 60V, VP0.3 =0 for Vbat = 0V
//            ADCount3 = C3 = 3.07/5.0 *8191 = 5029 cuentas
//            float Vbat_ext = K_VOLT*(float)C3    
float Vbat_ext = 0.0;
//            unsigned int iV_Inp3x10 =(unsigned int)(10.0*Vbat_ext); ;   // Integer 0-65536 x 10 V_Analg3 P0.3
#define K_VOLT 0.0119308

// Variables for Detection AD.. 
int     iV01;  // P0.1
int     iV03;  // P0.3
int     iV05;  // P0.5
int     iV07;  // P0.7
// Average values..
// Value name changed v3 02.1.2012
unsigned int   Av_ANLG1_P07_RPM  = 0;     //  Not used 4.3.12 Former VCh1, now rpm 2.1.12
unsigned int   Av_ANLG2_P05_IAE  = 0;     //  Former VCh2, now Iae 2.1.12
unsigned int   Av_ANLG3_P03_Vbat = 0;     //  Former VCh3, now Vbat 2.1.12
unsigned long  Av_PWR            = 0;     //  Vbat*Iae average Added 2.1.12 
unsigned int   AvVTemp           = 0;     //  Not used 4.3.12 Temperature.. 16-8-10 
unsigned char  j                 = 1;     // Counter for AVg.. (Reset to 1 -> 4.3.12)             
// Averaging Period.. - Try with 25-
// #define AVG_ITER 25
// 4.3.2012 - Too long (aprox 2s), try with 10
//-> aprox. 1s
// Try 6 to reduce this..
#define AVG_ITER 6

// New M4Expansion Interfase Structure 
// Rev 23-11-2011
// From 18-7-2010 Primeros 6 Bytes son R/W, resto R only
struct M4Exp3_I2C_Regs { // M4Exp3 I2C interface structure, first 6 are R/-W
BYTE bVector;     // To signal IRQ type, ID on Interrupt to master
BYTE bOut_0;      // Controls PWR_OK signal - active hi
BYTE bOut_1;      // Controls Buzzer - active hi
BYTE bOut_2;      // Auxiliary output - Not assigned
BYTE bOut_LED;    // LED on board - Active hi
BYTE bOut_K_Aux;  // Auxiliary Relay - Closes on hi
BYTE bIN0_P27;    // Input IN0 (0 or 1)
BYTE bIN1_P25;    // Input IN1 (0 or 1)
BYTE bIN2_P23;    // Input IN2 (0 or 1)
BYTE bIN2to0;      // Input value IN2-IN0 (000 to 111)- (Former ->Dos.Mode PB/2)
BYTE bIN3_P21;    // Input IN3 (0 or 1)
BYTE bIN4_P13;    // Input IN4 (0 or 1)
BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - (Former->Freno Mode PB/2)
BYTE bIN14_P20;   // Input IN14 (0 or 1)
BYTE bIN15_P22;   // Input IN15 (0 or 1)
BYTE bIN16_P24;   // Input IN16 (0 or 1)
BYTE bIN17_P26;   // Input IN17 (0 or 1)
unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>
char ID_cStr[6];  // Read only string for ID purpose
} M4E3_I2C_Regs;

/* OLD struct M4Exp_I2C_Regs { // M4Exp I2C interface structure, first 6 are R/-W
BYTE bVector;     // To signal IRQ type, ID on Interrupt to master
BYTE bOut_0;      // Controls PWR_OK signal - active hi
BYTE bOut_1;      // Controls Buzzer - active hi
BYTE bOut_2;      // Auxiliary output - Not assigned
BYTE bOut_LED;    // LED on board - Active hi
BYTE bOut_K_Aux;  // Auxiliary Relay - Closes on hi
BYTE bIN0_P27;    // Input IN0 (0 or 1)
BYTE bIN1_P25;    // Input IN1 (0 or 1)
BYTE bIN2_P23;    // Input IN2 (0 or 1)
BYTE bIN2to0;     // Input value IN2-IN0 (000 to 111)- Dos.Mode
BYTE bIN3_P21;    // Input IN3 (0 or 1)
BYTE bIN4_P13;    // Input IN4 (0 or 1)
BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
BYTE bIN14_P20;   // Input IN14 (0 or 1)
BYTE bIN15_P22;   // Input IN15 (0 or 1)
BYTE bIN16_P24;   // Input IN16 (0 or 1)
BYTE bIN17_P26;   // Input IN17 (0 or 1)
unsigned int iV_Tempx10;   // Integer 0-65536 x 10 Kelvin temperature P0.1
unsigned int iV_Inp1x10;   // Integer 0-65536 x 10 V_Analg1 P0.7
unsigned int iV_Inp2x10;   // Integer 0-65536 x 10 V_Analg2 P0.5
unsigned int iV_Inp3x10;   // Integer 0-65536 x 10 V_Analg3 P0.3
char ID_cStr[6];  // Read only string for ID purpose
} M4E_I2C_Regs;
*/

// 2.1.12 i_nfx Not used..
// 18-8-10 sent Avg_Calc() unsigned int i_nf; to Global, as i_nf1 for Temp, i_nf3 for Vbat..
// unsigned int i_nf1 = 0;  // Average 10x value of Temp, obtained in AvgCalc...
// unsigned int i_nf3 = 0;  // Average 10x value of Vbat, obtained in AvgCalc....

// Added For Serial 18.8.2010
#define TMPSTRLEN     25      // Temporary String LEngth 
char    nPeriod;
char    bData;      // 7.2.04 was BYTE, set to 0, now char, not init..
char    TmpStr[TMPSTRLEN+1];   // For Comm routines..

const BYTE DESC[] = "M4E revision 3b/TRIADC 4-03-2012";  // Update 4.3.12

// ****************************************
// PWR_OK Checking.. 19.8.2010
int   Hysteresis_Count = 0;   // Decrements from MAX
#define HYST_MAX 4
BYTE  PWR_OK_Status = 1;      // ON by default, always manipulate together with
                              // POrt1_2() instruction.. 

// ****************************************************************
// *** Function Prototypes ****************************************
// ****************************************************************   
void FlashLED(unsigned char count);   // LED flashing on P00
void ReadAD_Process(void);
void Input_Scan( void );
void Avg_Calc(void); 
void MSG(const char *s);             // 30.10.2005 Send s to COMport.. 
void MSGi(const char *s, int n);     // 30.10.05 Same, with int n also..
void MSGi_nCR(const char *s, int n); // 1.11.05 - Same as MSGi, no CR/LF..
void MSGL_nCR(const char *s, unsigned long nL); //5.1.2012 To show long values
void Show_M4E3_I2C_values(void);     // upd.2.1.12 Show inputs, etc from Struct..


// ****************************************************************
// *** Main Function **********************************************
// ****************************************************************   


void main()
{


   // First set POWER_OK to ON..
   Port1_2(1); // POWER_OK is ON by default 18.8.2010..
   PWR_OK_Status = 1; // Indicate this with Status 19.8.2010
   Port1_4(0); // BUZZ is OFF by default 18.8.2010..   
   Port1_6(0); // AUX2 is OFF by default 18.8.2010..   
      
   //  AvgReset_(Moved here from Justbefore_while(1) loop 17.6.06
   //  Change names 1.2.12
   Av_ANLG1_P07_RPM = 0;          //  Former VCh1, now rpm 2.1.12
   Av_ANLG2_P05_IAE = 0;          //  Former VCh2, now Iae 2.1.12
   Av_ANLG3_P03_Vbat = 0;         //  Former VCh3, now Vbat 2.1.12
   Av_PWR = 0;                    //  Intermediate average of Vbat*Iae 
   AvVTemp = 0;                   //  Temperature.. 16-8-10 
   
 
   // ****************************************************************
   // *** COMM ROUTINES       ****************************************
   // ****************************************************************   
    // For Freno23_c29 - Changed all to Counter_2, UART_8_2
    // Clk  VC3, Vc3 Divider = 2 
	//ClockSync Sync to SysClk
	//CompareOut Row_1_Output_1 (CLK_IN for UART is here) 
	//CompareType Less Than Or Equal
	//CompareValue 77
	//Enable High
	//IntDispatchMode ActiveStatus
	//InterruptAPI Enable
	//InterruptType Terminal Count
	//InvertEnable Normal
	//Period 155
	//TerminalCountOut None
	
    // VC3 as Sysclk (24MHz),with Divider =2 --12MHZ
	// Counter_8_2 uses VC3, with nPeriod =155, Compaer = 78.
	// This gives 12*1e6 / ((155+1)*8) = 9615.38baud
	// OK!!! Works 13.6 -- 9:30Hs.
  
   nPeriod = 155;   //3.2.04 Passed to comm.c
   //Counter8_2_WritePeriod(nPeriod);  -- Disabled 10.12.06
   //Counter8_2_WriteCompareValue(77); -- same
   Counter8_2_DisableInt();
   Counter8_2_Start();
   // Comm Counter ready..
   // Rutina retocada en comm.c, 10-6-06
   Comm_Start ();

   // #ifdef VERBOSE_MODE
   Comm_TxCRLF(); 
   Comm_TxCStr (PGM_MSG1); //10.6.2006
   Comm_TxCRLF();    
   // #endif
   #ifdef STARTUP_485
   //WaitBus485_Free();  
   //Comm_TxCStr(":h\r\n");	  // Send Only an ID on Startup..
   //WaitBus485_Free();     
   #endif 
   
   // ****************************************************************
   // *** A/D CONVERTER + BUFFER *************************************
   // ****************************************************************   
   // RefLow_Start(RefLow_HIGHPOWER); 3.2.06

   // Single converter with MUX - up to m4e_3b (02-2012)
    #ifdef SINGLE_ADC_MUX_REQUIRED
    Buffer_Start(Buffer_HIGHPOWER);
    ADCINCVR_1_Start(ADCINCVR_1_HIGHPOWER);
    #endif
      
    // TRIADC_1 converter on P0.3,5 - 4.3.2012
    Buffer_Vbat_Start(Buffer_Vbat_HIGHPOWER);
    Buffer_Iae_Start(Buffer_Iae_HIGHPOWER);
    // RPM do not start for now..
    Buffer_RPM_Start(Buffer_RPM_OFF);
    // 
    TRIADC_1_Start(TRIADC_1_HIGHPOWER); // Turn on Analog section 4.3.2012
    
   
   #ifdef SINGLE_ADC_MUX_REQUIRED
   //ACA00CR2 |= 0x1c;  //set testmux to ref+
   //ACA01CR2 |= 0x18;  //set testmux to ref- 
   ACB00CR2 |= 0x1c;  //set testmux to ref+ -- ACA00 is now ACB00..(29C)
   ACB01CR2 |= 0x18;  //set testmux to ref- 
   #endif

   bData = 0;         // 12.6.06 Initialize to 0 

   // Initialization Updated 19.7.2010
   // 18-7-2010 Primeros 6 Bytes son R/W, resto R only
   // struct M4Exp_I2C_Regs { // M4Exp I2C interface structure, first 6 are R/-W
   // BYTE bVector;     // To signal IRQ type, ID on Interrupt to master
   // BYTE bOut_0;      // Controls PWR_OK signal - active hi
   // BYTE bOut_1;      // Controls Buzzer - active hi
   // BYTE bOut_2;      // Auxiliary output - Not assigned
   // BYTE bOut_LED;    // LED on board - Active hi
   // BYTE bOut_K_Aux;  // Auxiliary Relay - Closes on hi
   // BYTE bIN0_P27;    // Input IN0 (0 or 1)
   // BYTE bIN1_P25;    // Input IN1 (0 or 1)
   // BYTE bIN2_P23;    // Input IN2 (0 or 1)
   // BYTE bIN2to0;      // Input value IN2-IN0 (000 to 111)- Dos.Mode
   // BYTE bIN3_P21;    // Input IN3 (0 or 1)
   // BYTE bIN4_P13;    // Input IN4 (0 or 1)
   // BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
   // BYTE bIN14_P20;   // Input IN14 (0 or 1)
   // BYTE bIN15_P22;   // Input IN15 (0 or 1)
   // BYTE bIN16_P24;   // Input IN16 (0 or 1)
   // BYTE bIN17_P26;   // Input IN17 (0 or 1)
   // unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
   // unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
   // unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
   // unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
   // unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>
   // char ID_cStr[6];  // Read only string for ID purpose   
   // } M4E_I2C_Regs;
   // a) Set vector & outputs initially to 0
   M4E3_I2C_Regs.bVector = 0;
   M4E3_I2C_Regs.bOut_0  = 1;  // Controls PWR_OK signal - active hi 
   M4E3_I2C_Regs.bOut_1  = 0;
   M4E3_I2C_Regs.bOut_2  = 0;
   M4E3_I2C_Regs.bOut_LED= 0;
   M4E3_I2C_Regs.bOut_K_Aux = 0;
   // b) Set vector & outputs initially to 0
   M4E3_I2C_Regs.iV_Temp      = 0;  // Temperatura
   M4E3_I2C_Regs.iV_ANLG2_P05 = 0;  // Integer 0-8191 V_Analg2 P0.5
   M4E3_I2C_Regs.iV_ANLG3_P03 = 0;  // Integer 0-8191 V_Analg3 P0.3
   M4E3_I2C_Regs.iV_ANLG1_P07 = 0;  // Integer 0-8191 V_Analg1 P0.7
   M4E3_I2C_Regs.iPWR         = 0;  // Integer ulong V_bat*Iaero 
   
   // ****************************************************************
   // *** WATCHDOG TIMER HABIL.  *************************************
   // ****************************************************************    
   M8C_EnableWatchDog;    // Added 15.2.07 ENABLE--- same as EM/12   


   // ****************************************************************
   // *** EzI2C HARDWARE I2C MODULE **********************************
   // *** Esclavo - direci�n '5'    **********************************
   // ****************************************************************   
   // Set up RAM buffer
   // 18-7-2010 Primeros 6 Bytes son R/W, resto R only
   // EzI2Cs_1_Start
   EzI2Cs_1_SetRamBuffer(sizeof(M4E3_I2C_Regs), 6, (BYTE *) &M4E3_I2C_Regs);  
   // EzI2Cs_1_SetRomBuffer(sizeof(DESC), DESC); // Set up ROM buffer
   M8C_EnableGInt ;     // Turn on interrupts
   M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07      
   EzI2Cs_1_Start();    // Turn on I2C
   // EzI2Cs_1_SetAddr(5); // Change address to 5 - En options del modulo,
   // lo pusimos como "static" en 5 (si es Dynamic, habilita esta funcion)

   // Avoid initialize problems when reading EVT with changed size.. 
   #ifdef VERBOSE_MODE
   MSG("ReadAD + AvgCalc..");
   #endif

   ReadAD_Process();              // Call A/D access routine..

   M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07
      
   Avg_Calc();                    // First load of averages...
   
   M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07



   while(1) {
    
    // FlashLED(1);  // Signal alive.. - Send to j==24 printing.. 4.3.12
    ReadAD_Process();              // Call A/D access routine..

    M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07
    
    // New version of Avg_Calc()  
    Avg_Calc();                    // Calculate averages...
     
    M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07

    // ***********************************************************************************
    // Move I/O scanning to loop AVG_ITER-2, to leave I2C bus free rest of time 4.3.12
    // ***********************************************************************************    
    if (j == (AVG_ITER - 2)){
      // *********************************************************************************
      // Check if inputs have been modified, to notify AVR Master. 
      Input_Scan();
      // *********************************************************************************
      // Now check if AVR has modified K_AUX via I2C, if so, act on RELAY output / 21.7.2010
      // Relay installed for SJ - not used. Will not be installed in PWRC/ii
      #ifdef RELAY_PSOC_USED
      if(M4E3_I2C_Regs.bOut_K_Aux == 0) Port0_2(0); // Relay is OFF..
      if(M4E3_I2C_Regs.bOut_K_Aux == 1) Port0_2(1); // Relay is ON..   
      #endif
      // *********************************************************************************
  
      // *********************************************************************************
      // Now check if AVR has modified bOut_1 via I2C, if so, act on Buzzer P1.4 / 21.7.2010
      if(M4E3_I2C_Regs.bOut_1 == 0) Port1_4(0); // Buzzer is OFF..
      if(M4E3_I2C_Regs.bOut_1 == 1) Port1_4(1); // Buzzer is ON..
      // *********************************************************************************
  
      // *********************************************************************************
      // Now check if AVR has modified bOut_2 via I2C, if so, act on AuxOut P1.6 / 21.7.2010
      if(M4E3_I2C_Regs.bOut_2 == 0) Port1_6(0); // AuxOut is OFF..
      if(M4E3_I2C_Regs.bOut_2 == 1) Port1_6(1); // AuxOut is ON..
      // *********************************************************************************
    }  // End if AVG_ITER -2 ..
    
    // v4.3.12 Only printout values once every AVG_ITER loops..
    if (j == (AVG_ITER - 1)){
       Port0_0(1); // TurnON_Led here to signal alive..
       Show_M4E3_I2C_values();
       Port0_0(0); // TurnOFF_Led 
       } // End if AVG_ITER -1 .. 
    } // End while..
}     // End main()..


// Flash LED Standard
// Argument is N� of flashes, #defines can change Length of 
// ON or OFF flashes  05-2009
// 18.8.2010 Add Clear WDT functions.. 

void FlashLED(unsigned char count)
{
unsigned int Delay1 = 0;
if(count == 0){   // Added for KEY only... 
      Port0_0(1); // TurnON_Led 
      do{
      ++Delay1;
      M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07
      }while(Delay1<DELAY_LED_SHORT);
      Port0_0(0); // TurnOFF_Led
      return;
      }
while (count--){
      Port0_0(1); // TurnON_Led 
      do{
      ++Delay1;
      M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07      
      }while(Delay1<DELAY_LED_MAX_ON);
      Port0_0(0); // TurnOFF_Led
      Delay1 = 0;
      do{
      ++Delay1;
      M8C_ClearWDTAndSleep;  //clears WDT and the SleepTimer.. 15.2.07      
      }while(Delay1<DELAY_LED_MAX_OFF);
      Delay1 = 0;   
      }
return;      
}


//* ReadAD_Process() -- Recycled from FRENO / v485_6 , etc for M4E 
//* Local development
//* Modified 4.3.2012 for TRIADC_1
//*********************************************************************************************************
//*                                         ReadAD_Process()
//*
//* TRIADC_1 assignements:
//* iV05-> unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
//* iV03-> unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
//* iV01->  RPM, iV07 not used..
//*  unsigned long iPWR;                // Run.Av_Integer 0-4GB producto <VBAT*IAERO>
//* 
//* Description : 
//* Assign TRIADC instead of one ADCINVR with MUX. 
//* (see Avg_Clc())    
//-------------------------------------------------
// Prototypes of the TRIADC_1 API.
//-------------------------------------------------
// extern void TRIADC_1_Start(BYTE bPower);
// extern void TRIADC_1_SetPower(BYTE bPower);
// extern void TRIADC_1_GetSamples(BYTE bNumSamples);
// extern void TRIADC_1_StopAD(void);
// extern void TRIADC_1_Stop(void);
// extern CHAR TRIADC_1_fIsData(void);
// extern CHAR TRIADC_1_fIsDataAvailable(void);
// extern INT  TRIADC_1_iGetData1(void);
// extern INT  TRIADC_1_iGetData2(void);
// extern INT  TRIADC_1_iGetData3(void);
// extern INT  TRIADC_1_iGetData1ClearFlag(void);
// extern INT  TRIADC_1_iGetData2ClearFlag(void);
// extern INT  TRIADC_1_iGetData3ClearFlag(void);
// extern void TRIADC_1_ClearFlag(void);
// extern void TRIADC_1_SetResolution(BYTE bResolution);
      
void ReadAD_Process(void){

    // Single operation for all channels..   4.3.2012
    TRIADC_1_ClearFlag(); 
    TRIADC_1_GetSamples(1);                   // Start TRIADC for single sample

    while(TRIADC_1_fIsDataAvailable() == 0);  // Wait for data to be ready    
    iV03 = TRIADC_1_iGetData1();          // Get Data from ADC Input1 - Vbat on P0.3    
    iV01 = TRIADC_1_iGetData2();          // Get Data from ADC Input2 - (set to 0 in PSoC-Config) RPM P0.2   
    iV05 = TRIADC_1_iGetData3ClearFlag(); // Get Data from ADC Input3 - Iaero on P0.5
    // All data collected..
     
    #ifdef SINGLE_ADC_MUX_REQUIRED      
      //Reading V_temp on P0.1
      AMX_IN =(AMX_IN & 0xfc)|0x00; //P0.1-Vtemp from TC1047A
      ADCINCVR_1_ClearFlag();
      ADCINCVR_1_GetSamples(1);   
      while(!ADCINCVR_1_fIsData());  // Endless loop - requieres TimeOut! 5.5.2010
      iV01 = ADCINCVR_1_iGetData();

      // Reading V_Analg3 (in PB2 -> batExt )
      AMX_IN =(AMX_IN & 0xfc)|0x01; //P0.3 
      ADCINCVR_1_ClearFlag();
      ADCINCVR_1_GetSamples(1);   
      while(!ADCINCVR_1_fIsData());  // Endless loop - requieres TimeOut! 5.5.2010
      iV03 = ADCINCVR_1_iGetData();
         
      //Reading V_analo2 - p05 in M4
      AMX_IN =(AMX_IN & 0xfc)|0x02;    //P0.5
      ADCINCVR_1_ClearFlag();
      ADCINCVR_1_GetSamples(1);   
      while(!ADCINCVR_1_fIsData());
      iV05 = ADCINCVR_1_iGetData();   // Save to Vanlg2 int value..18.8.2010

      //Reading V_Anlg1 - P0.7 in M4
      AMX_IN =(AMX_IN & 0xfc)|0x03;    //P0.7
      ADCINCVR_1_ClearFlag();
      ADCINCVR_1_GetSamples(1);   
      while(!ADCINCVR_1_fIsData());
      iV07 = ADCINCVR_1_iGetData();   // Save to Vanlg1 int value..18.8.2010
    #endif
 }
 


// ******************** INPUT SCANNING FUNCTION *************************************************************************
//    Input_Scan() -18.8.2010 / revised 2.1.12
//    I) Read Input IN0 requires testing P2.7: if high -> IN.0 =1, else IN.0=0
//    New Version, disable IRQ at start.. 
//                      M8CDisableInt;
//    This requires a) Copying PORT2 to Temp.
//                
//                     Temp_Holder=PRT2DR; // Make a single "photo" copy of port status..
//                     Temp = Temp_Holder;  // Don't overwrite copy.. 
//                  b) Temp = Temp & 0x80;   // Mask 0b1000 0000: Read P2_7, Temp will be 0x80 if P2.7 high, 0 if low
//                  c) if (Temp)  M4E3_I2C_Regs.bIN0_P27  = 1;
//                        else  M4E3_I2C_Regs.bIN0_P27  = 0;
//    Remember PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//    II) Read Input IN1 requires testing P2.5: if high -> IN.1 =1, else IN.1=0
//    This requires  (Use same Temp_Holder as a))
//                  d) Temp=Temp_Holder;
//                  e) Temp = Temp & 0x20;   // Mask 0b0010 0000: Read P2_5, Temp will be 0x20 if P2.5 high, 0 if low
//                  f) if (Temp)  M4E3_I2C_Regs.bIN1_P25  = 1;
//                        else  M4E3_I2C_Regs.bIN1_P25  = 0;
//    III) Read Input IN2 requires testing P2.3: if high -> IN.2 =1, else IN.2=0
//    This requires  (Use same Temp_Holder as a))
//                  d) Temp=Temp_Holder;
//                  e) Temp = Temp & 0x08;   // Mask 0b0000 1000: Read P2_3, Temp will be 0x08 if P2.3 high, 0 if low
//                  f) if (Temp)  M4E3_I2C_Regs.bIN2_P23  = 1;
//                        else  M4E3_I2C_Regs.bIN2_P23  = 0;
//    IV) Read Inputs IN2-0 as a Dosif_Mode status byte 000 to 111:
//    This can be done with 3 bits just calculated, in theory IN.2*pow(2,2)+IN.1*pow(2,1)+IN.0*pow(2,0)
//                  g) M4E3_I2C_Regs.bIN2to0  = (M4E3_I2C_Regs.bIN2_P23)*4+(M4E3_I2C_Regs.bIN1_P25)*2+M4E3_I2C_Regs.bIN0_P27;
//    To debug, these values should be sent out thru the serial port..
//    V) Now read
//                 BYTE bIN3_P21;    // Input IN3 (0 or 1)
//                 BYTE bIN4_P13;    // Input IN4 (0 or 1)
//                 BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
//    V-a) Read Input IN3 requires testing P2.1: if high -> IN.3 =1, else IN.3=0
//    This requires  (Use same Temp_Holder as a))
//                  h) Temp=Temp_Holder;
//                  i) Temp = Temp & 0x02;   // Mask 0b0000 0010: Read P2_1, Temp will be 0x02 if P2.1 high, 0 if low
//                  j,k) if (Temp)  M4E3_I2C_Regs.bIN3_P21  = 1;
//                        else  M4E3_I2C_Regs.bIN3_P21  = 0;
//    V-b) Read Input IN4 requires testing P1.3: if high -> IN.4 =1, else IN.4=0
//                     Temp=PRT1DR;    // Make a single copy on Temp, not used again..
//                  l) Temp = Temp & 0x08;   // Mask 0b0000 1000: Read P1_3, Temp will be 0x08 if P1.3 high, 0 if low
//                  m) if (Temp)  M4E3_I2C_Regs.bIN4_P13 = 1;
//                        else  M4E3_I2C_Regs.bIN4_P13  = 0;
//    VI) Read Inputs IN4-3 as a Freno_Mode status byte 00 to 11:
//    This can be done with 2 bits just calculated, in theory IN.4*pow(2,1)+IN.3*pow(2,0)
//                  n) M4E3_I2C_Regs.bIN4to3  = (M4E3_I2C_Regs.bIN4_P13)*2+M4E3_I2C_Regs.bIN3_P21;
//    VII) Rest of inputs, all on Port2
//      BYTE bIN14_P20;   // Input IN14 (0 or 1)
//      BYTE bIN15_P22;   // Input IN15 (0 or 1)
//      BYTE bIN16_P24;   // Input IN16 (0 or 1)
//      BYTE bIN17_P26;   // Input IN17 (0 or 1)
//      Remember PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//
//    VIIa) Read Input IN14 requires testing P2.0: if high -> IN.14 =1, else IN.14=0
//                  o) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  p) Temp = Temp & 0x01;   // Mask 0b0000 0001: Read P2_0, Temp will be 0x01 if P2.0 high, 0 if low
//                  q) if (Temp)  M4E3_I2C_Regs.bIN14_P20  = 1;
//                        else  M4E3_I2C_Regs.bIN14_P20  = 0;
//    VIIb) Read Input IN15 requires testing P2.2: if high -> IN.15 =1, else IN.15=0
//                  r) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  s) Temp = Temp & 0x04;   // Mask 0b0000 0100: Read P2_2, Temp will be 0x04 if P2.2 high, 0 if low
//                  t) if (Temp)  M4E3_I2C_Regs.bIN15_P22  = 1;
//                        else  M4E3_I2C_Regs.bIN15_P22  = 0;
//    VIIc) Read Input IN16 requires testing P2.4: if high -> IN.16 =1, else IN.16=0
//                  u) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  v) Temp = Temp & 0x10;   // Mask 0b0001 0000: Read P2_4, Temp will be 0x10 if P2.4 high, 0 if low
//                  w) if (Temp)  M4E3_I2C_Regs.bIN16_P24  = 1;
//                        else  M4E3_I2C_Regs.bIN16_P24  = 0;
//    VIId) Read Input IN17 requires testing P2.6: if high -> IN.17 =1, else IN.17=0
//                  u) Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
//                  v) Temp = Temp & 0x40;   // Mask 0b0100 0000: Read P2_6, Temp will be 0x40 if P2.6 high, 0 if low
//                  w) if (Temp)  M4E3_I2C_Regs.bIN17_P26  = 1;
//                        else  M4E3_I2C_Regs.bIN17_P26  = 0;
// ******************** OK - Trhu with all inputs.. *******************************************************************
//    Last step.                 M8CEnableInt;

void Input_Scan( void ) {
             unsigned char Temp_Holder;
             unsigned char Temp;

//    In new version - 18.8.2010 Clear INTs before input scanning..       
                    M8C_DisableGInt;

//    This requires a) Copying PORT2 to Temp.
                    Temp_Holder=PRT2DR; // Make a single "photo" copy of port status..
                    Temp = Temp_Holder;  // Don't overwrite copy..
// Pin IN.0 = P2_7                     
                    Temp = Temp & 0x80;   // Mask 0b1000 0000: Read P2_7, Temp will be 0x80 if P2.7 high, 0 if low
                    if (Temp)  M4E3_I2C_Regs.bIN0_P27  = 1;
                      else  M4E3_I2C_Regs.bIN0_P27  = 0;
//    Remember PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//    II) Read Input IN1 requires testing P2.5: if high -> IN.1 =1, else IN.1=0
//    This requires  (Use same Temp_Holder as a))
                    Temp=Temp_Holder;
                    Temp = Temp & 0x20;   // Mask 0b0010 0000: Read P2_5, Temp will be 0x20 if P2.5 high, 0 if low
                    if (Temp)  M4E3_I2C_Regs.bIN1_P25  = 1;
                     else  M4E3_I2C_Regs.bIN1_P25  = 0;
//    III) Read Input IN2 requires testing P2.3: if high -> IN.2 =1, else IN.2=0
//    This requires  (Use same Temp_Holder as a))
                    Temp=Temp_Holder;
                    Temp = Temp & 0x08;   // Mask 0b0000 1000: Read P2_3, Temp will be 0x08 if P2.3 high, 0 if low
                    if (Temp)  M4E3_I2C_Regs.bIN2_P23  = 1;
                     else  M4E3_I2C_Regs.bIN2_P23  = 0;
//    IV) Read Inputs IN2-0 as a Dosif_Mode status byte 000 to 111:
//    This can be done with 3 bits just calculated, in theory IN.2*pow(2,2)+IN.1*pow(2,1)+IN.0*pow(2,0)
                    M4E3_I2C_Regs.bIN2to0  = (M4E3_I2C_Regs.bIN2_P23)*4+(M4E3_I2C_Regs.bIN1_P25)*2+M4E3_I2C_Regs.bIN0_P27;
//    To debug, these values should be sent out thru the serial port..
//    V) Now read
//                 BYTE bIN3_P21;    // Input IN3 (0 or 1)
//                 BYTE bIN4_P13;    // Input IN4 (0 or 1)
//                 BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
//    V-a) Read Input IN3 requires testing P2.1: if high -> IN.3 =1, else IN.3=0
//    This requires  (Use same Temp_Holder as a))
                    Temp=Temp_Holder;
                    Temp = Temp & 0x02;   // Mask 0b0000 0010: Read P2_1, Temp will be 0x02 if P2.1 high, 0 if low
                    if (Temp)  M4E3_I2C_Regs.bIN3_P21  = 1;
                        else  M4E3_I2C_Regs.bIN3_P21  = 0;
//    V-b) Read Input IN4 requires testing P1.3: if high -> IN.4 =1, else IN.4=0
                    Temp=PRT1DR;    // Make a single copy on Temp, not used again..
                    Temp = Temp & 0x08;   // Mask 0b0000 1000: Read P1_3, Temp will be 0x08 if P1.3 high, 0 if low
                    if (Temp)  M4E3_I2C_Regs.bIN4_P13 = 1;
                        else  M4E3_I2C_Regs.bIN4_P13  = 0;
//    VI) Read Inputs IN4-3 as a Freno_Mode status byte 00 to 11:
//    This can be done with 2 bits just calculated, in theory IN.4*pow(2,1)+IN.3*pow(2,0)
                    M4E3_I2C_Regs.bIN4to3  = (M4E3_I2C_Regs.bIN4_P13)*2+M4E3_I2C_Regs.bIN3_P21;
//    VII) Rest of inputs, all on Port2
//      BYTE bIN14_P20;   // Input IN14 (0 or 1)
//      BYTE bIN15_P22;   // Input IN15 (0 or 1)
//      BYTE bIN16_P24;   // Input IN16 (0 or 1)
//      BYTE bIN17_P26;   // Input IN17 (0 or 1)
//      Remember PORT2: Acts all as inputs
//          P2.7  P2.6  P2.5  P2.4   P2.3  P2.2  P2.1  P2.0
//          IN0   IN17  IN1   IN16   IN2   IN15  IN3   IN14
//
//    VIIa) Read Input IN14 requires testing P2.0: if high -> IN.14 =1, else IN.14=0
                   Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
                   Temp = Temp & 0x01;   // Mask 0b0000 0001: Read P2_0, Temp will be 0x01 if P2.0 high, 0 if low
                   if (Temp)  M4E3_I2C_Regs.bIN14_P20  = 1;
                        else  M4E3_I2C_Regs.bIN14_P20  = 0;
//    VIIb) Read Input IN15 requires testing P2.2: if high -> IN.15 =1, else IN.15=0
                   Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
                   Temp = Temp & 0x04;   // Mask 0b0000 0100: Read P2_2, Temp will be 0x04 if P2.2 high, 0 if low
                   if (Temp)  M4E3_I2C_Regs.bIN15_P22  = 1;
                        else  M4E3_I2C_Regs.bIN15_P22  = 0;
//    VIIc) Read Input IN16 requires testing P2.4: if high -> IN.16 =1, else IN.16=0
                   Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
                   Temp = Temp & 0x10;   // Mask 0b0001 0000: Read P2_4, Temp will be 0x10 if P2.4 high, 0 if low
                   if (Temp)  M4E3_I2C_Regs.bIN16_P24  = 1;
                        else  M4E3_I2C_Regs.bIN16_P24  = 0;
//    VIId) Read Input IN17 requires testing P2.6: if high -> IN.17 =1, else IN.17=0
                   Temp = Temp_Holder;   // Temp_Holder still with last PORT2 contents,Don't overwrite copy.. 
                   Temp = Temp & 0x40;   // Mask 0b0100 0000: Read P2_6, Temp will be 0x40 if P2.6 high, 0 if low
                   if (Temp)  M4E3_I2C_Regs.bIN17_P26  = 1;
                        else  M4E3_I2C_Regs.bIN17_P26  = 0;
//    In new version, INTs disabled so now re-enable..  18.8.2010
                   M8C_EnableGInt;                      
}                        


//*********************************************************************************************************
//*                                         Avg_Calc
//* -->2.1.2012 Compute Averages - for M4E_3 board in PWRC/ii apps.. 
//* To update..
//* unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
//* unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
//* unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
//* unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
//* unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>//*  
//
//* Uses:
//* unsigned int   Av_ANLG1_P07_RPM = 0;          //  Former VCh1, now rpm 2.1.12
//* unsigned int   Av_ANLG2_P05_IAE = 0;          //  Former VCh2, now Iae 2.1.12
//* unsigned int   Av_ANLG3_P03_Vbat = 0;         //  Former VCh3, now Vbat 2.1.12
//* unsigned int   AvVTemp = 0;        // Temperature.. 16-8-10 
//* unsigned long  Av_PWR = 0;         // running average of Iae*Vbat
//* unsigned char  j      = 5;         // Counter for AVg.. (Don't reset to 1, min is 5 -)             
//  Averaging Period.. - Try with 25-
//
// Raw running average, no EU constants applied (only in PWRC/ii) 
//  

void Avg_Calc(void){ 
unsigned long uL_PWR;
int Dif_Vavg;
        if (j == 0) j = 5;   // Safety check.. 6.3 -to 5
        // Vch1,2,3 name update 
        // not used 4.3.12 Av_ANLG1_P07_RPM = Av_ANLG1_P07_RPM - (int)(Av_ANLG1_P07_RPM / j) + (int)(iV07 / j) ;  // Calculate RPM  - Average (int)        
        Av_ANLG2_P05_IAE = Av_ANLG2_P05_IAE - (int)(Av_ANLG2_P05_IAE / j) + (int)(iV05 / j) ;  // Calculate IAE - Average (int)        
        Av_ANLG3_P03_Vbat = Av_ANLG3_P03_Vbat - (int)(Av_ANLG3_P03_Vbat / j) + (int)(iV03 / j) ;  // Calculate Vbat - Average (int)
        uL_PWR = (unsigned long)(iV05)*(unsigned long)(iV03);   // Intermediate value..2.1.12 Added
        Av_PWR = Av_PWR - (unsigned long)(Av_PWR / j) + (unsigned long)(uL_PWR / j); // 2.1.12 Added
        // not used 4.3.12 AvVTemp = AvVTemp - (int)(AvVTemp / j) + (int)(iV01 / j) ;  // Calculate Temp=P0.1 - Average (int)
        M8C_ClearWDTAndSleep; // Clr WDT and the SleepTimer.. 15.2.07
                
       #ifdef DEBUG_REQUIRED_VTRIADC
        // Commented out on TRIADC version 4.3.2012
        // Show progress in Temperature calc .. 18.8.2010 on COM debug port..
        MSGi_nCR("iV01:,",iV01);
        MSGi_nCR("AvTemp:,",(int)AvVTemp);              // print out as int 2.1.12..

        // Show progress in RPM.. similar..
        MSGi_nCR("iV07:,",iV07);
        MSGi_nCR("iRPM_avg:,",(int)Av_ANLG1_P07_RPM );  // print out as int 2.1.12..

        // Show progress in Iaero.. similar..
        MSGi_nCR("iV05:,",iV05);
        MSGi_nCR("iIAer_avg:,",(int)Av_ANLG2_P05_IAE);  // print out as int 2.1.12..

        // Show progress in Vbat.. similar..
        MSGi_nCR("iV03:,",iV03);
        MSGi_nCR("iVbat_avg:,",(int)Av_ANLG3_P03_Vbat); // print out as int 2.1.12..
        
        UART_2_PutCRLF();
        // 5.1.2012 Use: void MSGL_nCR(const char *s, unsigned long nL        
        MSGL_nCR("  uL_PWR:,",uL_PWR); // print out as unsigned long 5.1.12..
        MSGL_nCR("  Av_PWR:,",Av_PWR); // print out as unsigned long 5.1.12..

        // long ltoa (char  *string, unsigned long value, int base)
        
        // Show avg. index    
        MSGi_nCR(",j:,",j);
        UART_2_PutCRLF();
       #endif
            
        if (++j == AVG_ITER)  // 4.3.12 This occurs every 2sec aprox. if AVG_ITER = 25.
                              // This is too long, so try with AVG_ITER = 10   
              { 
              // Averaging period Reached.. 
              // Not used 4.3.12  a) Process Temperature..
              // MSGi_nCR("Copiado T_av:,",(int)AvVTemp);             // print out as int..
              // In new version - 18.8.2010 Clear INTs before updating..       
              // same 2.1.2012
              // M8C_DisableGInt;
              // M4E3_I2C_Regs.iV_Temp = AvVTemp;              
              // M8C_EnableGInt;
              // OK updated  

              // b)Not used 4.3.12  Process RPM..
              // MSGi_nCR("Copiado RPM_av:,",(int)Av_ANLG1_P07_RPM);   // print out as int..
              // In new version - 18.8.2010 Clear INTs before updating..       
              // same 2.1.2012
              // M8C_DisableGInt;
              // M4E3_I2C_Regs.iV_ANLG1_P07 = Av_ANLG1_P07_RPM;              
              // M8C_EnableGInt;
              // OK updated  

              // c) Process Iaero..
              // All messages at the end.. 4.3.12
               // In new version - 18.8.2010 Clear INTs before updating..       
              // same 2.1.2012
              M8C_DisableGInt;
              M4E3_I2C_Regs.iV_ANLG2_P05 = Av_ANLG2_P05_IAE;              
              M8C_EnableGInt;
              // OK updated  

              // d) Vbat Process
              // All messages at the end.. 4.3.12              
              // In new version - 18.8.2010 Clear INTs before updating..    
              // same 2.1.2012                 
              M8C_DisableGInt;
              M4E3_I2C_Regs.iV_ANLG3_P03 = Av_ANLG3_P03_Vbat;            
              M8C_EnableGInt;
              
              // d) PWR Process
              // All messages at the end.. 4.3.12              
              // In new version - 18.8.2010 Clear INTs before updating..    
              // same 2.1.2012                 
              M8C_DisableGInt;
              M4E3_I2C_Regs.iPWR = Av_PWR;            
              M8C_EnableGInt;              
              
              // OK updated - all messages here 4.3.12 
              UART_2_PutCRLF();              
              MSGi_nCR("Idx_j:,",j);              
              MSGi_nCR(" Copy Vbat_av to I2C:,",(int)Av_ANLG3_P03_Vbat); // print out as int..              
              MSGi_nCR(" Copy Iae_av:,",(int)Av_ANLG2_P05_IAE);   // print out as int..              
              MSGL_nCR(" Copy PWR_av:,",Av_PWR); // print out as unsigned long.. 
              UART_2_PutCRLF();
              j = 1; // Reset AVG couter.. (was 5, change back to 1 - 4.3.12) 
         }    // end if ++j..                 
return;
}              


//* 30.10.2005  - All local development
//*********************************************************************************************************
//*                                         MSG()
//*
//* Description : This function takes string s, and sends it as a COM message.

void MSG(const char *s){
      //#ifdef VERBOSE_MODE
	   Comm_TxCRLF();                       
	   Comm_TxCStr (s);
	   Comm_TxCRLF();                    
	  //#endif 
}

//* 30.10.2005  - All local development
//*********************************************************************************************************
//*                                         MSGi()
//*
//* Description : This function takes string s, an int i,  and sends both as a COM message.
//* 16.10.09 Add VERBOSE_MODE compiler switch..



void MSGi(const char *s, int n){
      //#ifdef VERBOSE_MODE
	   Comm_TxCRLF();                       
       Comm_TxCStr (s);
       itoa(TmpStr, n, 10);
       Comm_TxStr (TmpStr);	
   	   Comm_TxCRLF();  
   	  //#endif                   
}


//* 1.11.2005  - All local development
//*********************************************************************************************************
//*                                         MSGi_nCR()
//*
//* Description : This function takes string s, an int i,  and sends both as a COM message.
//* _nCR avoids CR,LF
//* 

void MSGi_nCR(const char *s, int n){
       Comm_TxCStr (s);
       itoa(TmpStr, n, 10);
       Comm_TxStr (TmpStr);	
}

//* 05-01-2012  - All local development
//*********************************************************************************************************
//*                                         MSGL_nCR()
//*
//* Description : This function takes string s, an int i,  and sends both as a COM message.
//* long ltoa (char  *string, unsigned long value, int base)



void MSGL_nCR(const char *s, unsigned long nL){
      //#ifdef VERBOSE_MODE
       Comm_TxCStr (s);
       ltoa(TmpStr, nL, 10);
       Comm_TxStr (TmpStr);	
   	  //#endif                   
}

//*********************************************************************************************************
//*                                         Show_M4E_I2C_values()
//* -->18.8.2010 Compute Averages - for M4E_2 board.. 
//* To update.. Show inputs, etc from Struct.. on COM debug port..
//* 
// struct M4Exp_I2C_Regs { // M4Exp I2C interface structure, first 6 are R/-W
// BYTE bVector;     // To signal IRQ type, ID on Interrupt to master
// BYTE bOut_0;      // Controls PWR_OK signal - active hi
// BYTE bOut_1;      // Controls Buzzer - active hi
// BYTE bOut_2;      // Auxiliary output - Not assigned
// BYTE bOut_LED;    // LED on board - Active hi
// BYTE bOut_K_Aux;  // Auxiliary Relay - Closes on hi
// BYTE bIN0_P27;    // Input IN0 (0 or 1)
// BYTE bIN1_P25;    // Input IN1 (0 or 1)
// BYTE bIN2_P23;    // Input IN2 (0 or 1)
// BYTE bIN2to0;      // Input value IN2-IN0 (000 to 111)- Dos.Mode
// BYTE bIN3_P21;    // Input IN3 (0 or 1)
// BYTE bIN4_P13;    // Input IN4 (0 or 1)
// BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
// BYTE bIN14_P20;   // Input IN14 (0 or 1)
// BYTE bIN15_P22;   // Input IN15 (0 or 1)
// BYTE bIN16_P24;   // Input IN16 (0 or 1)
// BYTE bIN17_P26;   // Input IN17 (0 or 1)
// unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
// unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
// unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
// unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
// unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>//*  
// char ID_cStr[6];  // Read only string for ID purpose   
// } M4E3_I2C_Regs;

void Show_M4E3_I2C_values(void){
   int iTemp; // 2.1.2012 to show PWR..
   //Salidas..
   UART_2_CPutString("Salidas ...");
   MSGi_nCR(" bV:,",(int)M4E3_I2C_Regs.bVector);         // print out as int..
   MSGi_nCR(" PW_ok:,",(int)M4E3_I2C_Regs.bOut_0);       // print out as int..Controls PWR_OK signal - active hi 
   MSGi_nCR(" Bz:,",(int)M4E3_I2C_Regs.bOut_1);          // Buzzer
   MSGi_nCR(" Ou2:,",(int)M4E3_I2C_Regs.bOut_2);         // not used
   MSGi_nCR(" LED:,",(int)M4E3_I2C_Regs.bOut_LED);       // LED  
   MSGi_nCR(" Kaux:,",(int)M4E3_I2C_Regs.bOut_K_Aux);    // Relay AUX
   Comm_TxCRLF();  
   // entradas..
   // BYTE bIN0_P27;    // Input IN0 (0 or 1)
   // BYTE bIN1_P25;    // Input IN1 (0 or 1)
   // BYTE bIN2_P23;    // Input IN2 (0 or 1)
   // BYTE bIN2to0;      // Input value IN2-IN0 (000 to 111)- Dos.Mode
   UART_2_CPutString("Entradas IN0-IN2..");
   MSGi_nCR(" IN0:,",(int)M4E3_I2C_Regs.bIN0_P27);       // print out as int..
   MSGi_nCR(" IN1:,",(int)M4E3_I2C_Regs.bIN1_P25);       // print out as int..   
   MSGi_nCR(" IN2:,",(int)M4E3_I2C_Regs.bIN2_P23);       // print out as int..   
   MSGi_nCR(" IN2-0:,",(int)M4E3_I2C_Regs.bIN2to0);      // print out as int..      
   Comm_TxCRLF();  

   // BYTE bIN3_P21;    // Input IN3 (0 or 1)
   // BYTE bIN4_P13;    // Input IN4 (0 or 1)
   // BYTE bIN4to3;      // Input value IN4-IN3 (00 to 11) - Freno Mode.
   UART_2_CPutString("Entradas IN3-IN4..");
   MSGi_nCR(" IN3:,",(int)M4E3_I2C_Regs.bIN3_P21);       // print out as int..
   MSGi_nCR(" IN4:,",(int)M4E3_I2C_Regs.bIN4_P13);       // print out as int..   
   MSGi_nCR(" IN3-4:,",(int)M4E3_I2C_Regs.bIN4to3);      // print out as int..      
   Comm_TxCRLF();  
   // BYTE bIN14_P20;   // Input IN14 (0 or 1)
   // BYTE bIN15_P22;   // Input IN15 (0 or 1)
   // BYTE bIN16_P24;   // Input IN16 (0 or 1)
   // BYTE bIN17_P26;   // Input IN17 (0 or 1)
   UART_2_CPutString("Entradas IN14-IN17..");
   MSGi_nCR(" IN14:,",(int)M4E3_I2C_Regs.bIN14_P20);       // print out as int..
   MSGi_nCR(" IN15:,",(int)M4E3_I2C_Regs.bIN15_P22);       // print out as int..   
   MSGi_nCR(" IN16:,",(int)M4E3_I2C_Regs.bIN16_P24);       // print out as int..   
   MSGi_nCR(" IN17:,",(int)M4E3_I2C_Regs.bIN17_P26);       // print out as int..    
   Comm_TxCRLF();  
   
   // Not used 4.3.12 MSGi_nCR(" Vt:,",(int)M4E3_I2C_Regs.iV_Temp);  // Temperatura
// unsigned int iV_Temp;    // Integer 0-65536  Kelvin temperature P0.1
// unsigned int iV_ANLG2_P05;   // Run.Av_Integer 0-65536 V_Anlg2 = IAERO= P0.5
// unsigned int iV_ANLG3_P03;   // Run.Av_Integer 0-65536 V_Anlg3 = VBAT = P0.3
// unsigned int iV_ANLG1_P07;   // Run.Av_Integer 0-65536 V_Anlg1 = FREC = P0.7
// unsigned long iPWR;          // Run.Av_Integer 0-4GB producto <VBAT*IAERO>//*  
//   
   // Not used 4.3.12  MSGi_nCR(" Av_RPM-P07:,",(int)M4E3_I2C_Regs.iV_ANLG1_P07);  // Integer 0-65536 V_Analg1 P0.7 rpm
   MSGi_nCR(" iV05:,",iV05);
   MSGi_nCR(" Av_IAE-P05:,",(int)M4E3_I2C_Regs.iV_ANLG2_P05);  // Integer 0-65536 V_Analg2 P0.5 iaero
   MSGi_nCR(" iV03:,",iV03);   
   MSGi_nCR(" Av_Vbat-P03:,",(int)M4E3_I2C_Regs.iV_ANLG3_P03);  //Integer 0-65536 V_Analg2 P0.3 vbat
   Comm_TxCRLF(); 

   // 5.1.2012 Use: void MSGL_nCR(const char *s, unsigned long nL        
   // MSGL_nCR("  uL_PWR:,",uL_PWR); // print out as unsigned long 5.1.12..
   MSGL_nCR("  Av_PWR:,",Av_PWR); // print out as unsigned long 5.1.12..
   
   // Unnecesary calcs - 3.3.2012
   #ifdef SEPARATE_AVPOWER
   MSGi_nCR(" Av_PWR/10000:,",(int)(M4E3_I2C_Regs.iPWR/10000));  //Integer (8192*8192 = 67108864)/10000 shows 6710
   // Para sacar el remainder, usamos float fmod(float y,float z);   
   // Shows y - n*z, with n=(int)(y/z) -> si y=67108864.0, z=10000.0, fmod da 8864.0
   iTemp = (int) fmod ((float)M4E3_I2C_Regs.iPWR, 10000.0);
   MSGi_nCR(" Remainder de Av_PWR/10000:,",iTemp);   
   #endif
   
   Comm_TxCRLF(); 
   // End function.. 18.8.2010
}   