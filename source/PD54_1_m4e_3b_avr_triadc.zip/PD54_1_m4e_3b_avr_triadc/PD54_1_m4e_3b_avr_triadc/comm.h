//=============================================================================
//
//                       Adapted from: PSoC Design Challenge 2002
//                           (PROJECT NUMBER 248) Revised
//
//=============================================================================
//  FILENAME:   comm.h
//   VERSION:   1.05 by R.Oliva 
//      DATE:   10-2-2006
//=============================================================================

#ifndef COMM_HFILE
#define COMM_HFILE
#define COMMTIMEOUT 100   

// ********** From Thermistor5.h 27.01.2004 For Serial
// Defines
#define CR 0x0D
#define LF 0x0A
#define HEXBASE 16
#define NAK_RESPONSE 0x00
#define TMPSTRLEN_1     25      // Also in main.c
// #define RX_LOCAL_FUNCTION
// Global-External
extern char    TmpStr[TMPSTRLEN_1+1];   

void Comm_Start (void);
void Comm_Stop (void);
void Comm_TxInt (int i);
void Comm_TxCStr (const char *TxStr);
void Comm_TxStr (char *TxStr);
void Comm_TxByte (char ch);
void Comm_TxCRLF (void);

#ifdef RX_LOCAL_FUNCTION
void Comm_RxTmpStr (void);  // ifdef'd out.. 2006 for new API5.2
#endif

#endif
